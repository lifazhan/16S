sample.xlsx：样本信息
    Sample，Group：联合分析图表中展示的样本名称和分组；
    Meta_sample，Meta_group：代谢组分析所用的样本名称和分组；
    Micro_sample，Micro_group：微生物组分析所用的样本名称和分组；



代谢物的定量数据：
    不取对数：
        metabolome.1.abundance.xlsx（原始值，只有一个文件）
    取自然对数（log）：
        metabolome.1.abundance.log.xlsx，原始值取 log 计算（由于原始数据可能含 0，原始值会加上极小值 1E-10 再取对数）
        metabolome.1.abundance.xlsx，原始值
    可以设置取自然对数，也可取其他底数 log2/log10。

    Index：代谢物 ID，原代谢组 ID 中的 * 会替换成 _
    Compounds：代谢物英文名称
    物质：代谢物中文名称
    样本列：代谢物在所有样本中的定量数据
    其他：代谢物注释信息，也可能没有这些列

代谢组的差异分析结果：metabolome.2.significant_diff/*_filter.xlsx
    如果设置取对数，则该文件是取对数计算后的数据，否则是原始数据。

    Index：代谢物 ID，原代谢组 ID 中的 * 会替换成 _
    Compounds：代谢物英文名称
    物质：代谢物中文名称



微生物的相对定量数据：microbiome.1.abundance/
    不取对数：
        {taxon}_relative_abundance.xlsx
    取 log2 对数：
        {taxon}_relative_abundance.log2.xlsx，原始值取 log2 计算（由于原始数据含 0，原始值会加上极小值 1E-10 再取对数）
        raw/{taxon}_relative_abundance.xlsx，原始值

    Taxonomy：微生物的分类学信息
    其他列：微生物在所有样本中的相对定量数据

    注：taxon 是门（Phylum）、纲（Class）、目（Order）、
               科（Family）、属（Genus）、种（Species）、ASV 中的一种，下同

微生物组的差异分析结果：microbiome.2.significant_diff_taxonomy/{taxon}/*_filter.xlsx
    如果设置取对数，则该文件是取对数计算后的数据，否则是原始数据。
    
    Taxonomy：微生物的分类学信息
    其他列：微生物在所有样本中的相对定量数据
