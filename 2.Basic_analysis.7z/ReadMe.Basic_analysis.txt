代谢组的 PCA 分析结果：metabolome_PCA

微生物组的 PCA 分析结果：microbiome_PCA/{taxon}
    注：taxon 是门（Phylum）、纲（Class）、目（Order）、
               科（Family）、属（Genus）、种（Species）、ASV 中的一种

结果文件说明，
    2D PCA 结果：*_PCA.pdf/png

    含置信区间的 2D PCA：*_PCA_ellipse.pdf/png：对于包含 4 个样本或以上的分组，会在 
        2D PCA 图的基础上添加置信区间。包含 3 个样本的分组也可以添加置信区间，默认不画。

    3D PCA 结果：*_PCA3D.*

    PCA 各组分结果：*_PCA_eigenvector.xlsx

    PCA 各组分统计结果：*_PCA_eigenvalue.xlsx
        standard deviation：主成分标准差
        Proportion of Variance：主成分方差的占比
        Cumulative Proportion：主成分累计贡献率

    PCA 前 5 个主成分的可解释变异结果：*_PCA_variance.*
